﻿using System;

namespace zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Описание пользовательских классов (человек, сотрудник, рабочий (допустим admin), - реализовал в первом задании)
        }
    }
}
